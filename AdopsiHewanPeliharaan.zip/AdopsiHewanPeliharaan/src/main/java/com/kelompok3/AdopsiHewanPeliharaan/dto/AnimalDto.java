package com.kelompok3.AdopsiHewanPeliharaan.dto;

import lombok.Data;

@Data
public class AnimalDto {
    private int id;
    private String nama_hewan;
    private String type_hewan;
    private String available;
}
