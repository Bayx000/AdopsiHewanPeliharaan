package com.kelompok3.AdopsiHewanPeliharaan.dto;

import lombok.Data;

@Data
public class AdopterDto {
    private int id;
    private String nama;
    private String email;
    private String nomor_telepon;
    private String addres;
}
