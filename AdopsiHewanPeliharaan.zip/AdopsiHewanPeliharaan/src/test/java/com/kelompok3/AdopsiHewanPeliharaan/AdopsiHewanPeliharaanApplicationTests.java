package com.kelompok3.AdopsiHewanPeliharaan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdopsiHewanPeliharaanApplicationTests {

	@Test
	void contextLoads() {
	}

}
